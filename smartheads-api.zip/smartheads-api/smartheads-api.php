<?php
/*
Plugin Name: Smartheads Dashboard Update API
Description: Beveiligde API voor Smartheads Dashboard om Core, Plugin, Theme status, HTTP health, SSL en offline history uit te lezen.
Version: 2.4
Author: Bas / Smartheads
*/

if (!defined('ABSPATH')) exit;

define('SH_DASHBOARD_API_KEY', 'f9e1c4b7a3d8f0c2e6b1a9d4f7c3e8a1b6d9f2c4e7a0b3d5f8c1e4a7b2d9f3c6e1a4b7d0f2c9e5a1d4b8f0c3e6a9d2f5b1c7e4a0f8d3');

// Post types om te monitoren
define('SH_MONITOR_POST_TYPES', ['page', 'post']);

// Offline log: maximaal aantal entries bewaren
define('SH_OFFLINE_LOG_MAX', 50);

// SSL: alleen waarschuwen binnen 14 dagen (rood) of verlopen
define('SH_SSL_CRITICAL_DAYS', 14);

// HTTP health: maximaal aantal URLs checken per request (voorkomt 504 op grote sites)
define('SH_HTTP_MAX_URLS', 10);

// HTTP health: timeout per individuele request in seconden
define('SH_HTTP_TIMEOUT', 5);

// ─── REST route ───────────────────────────────────────────────────────────────

add_action('rest_api_init', function () {
    register_rest_route('dashboard/v1', '/updates', [
        'methods'             => 'GET',
        'callback'            => 'sh_dashboard_update_api_callback',
        'permission_callback' => '__return_true',
    ]);
});

// CORS headers
add_action('rest_api_init', function() {
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
    add_filter('rest_pre_serve_request', function($value) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET');
        header('Access-Control-Allow-Credentials: true');
        return $value;
    });
}, 15);

// ─── Helper: Offline log ──────────────────────────────────────────────────────

function sh_get_offline_log(): array {
    return get_option('sh_offline_log', []);
}

function sh_append_offline_log(string $url, int $status_code, string $reason): void {
    $log   = sh_get_offline_log();
    $log[] = [
        'url'         => $url,
        'timestamp'   => time(),
        'status_code' => $status_code,
        'reason'      => $reason,
    ];

    // Bewaar alleen de laatste N entries
    if (count($log) > SH_OFFLINE_LOG_MAX) {
        $log = array_slice($log, -SH_OFFLINE_LOG_MAX);
    }

    update_option('sh_offline_log', $log, false);
}

// ─── Helper: SSL check ────────────────────────────────────────────────────────

function sh_check_ssl(string $domain): array {
    $host = parse_url('https://' . $domain, PHP_URL_HOST) ?: $domain;

    if (!function_exists('stream_socket_client')) {
        return [
            'valid'          => false,
            'days_remaining' => null,
            'expiry_date'    => null,
            'status'         => 'error',
            'message'        => 'stream_socket_client niet beschikbaar op deze server.',
        ];
    }

    $context = stream_context_create([
        'ssl' => [
            'capture_peer_cert' => true,
            'verify_peer'       => false,
            'verify_peer_name'  => false,
        ]
    ]);

    $errno  = 0;
    $errstr = '';
    $socket = @stream_socket_client(
        "ssl://{$host}:443",
        $errno,
        $errstr,
        10,
        STREAM_CLIENT_CONNECT,
        $context
    );

    if (!$socket) {
        return [
            'valid'          => false,
            'days_remaining' => null,
            'expiry_date'    => null,
            'status'         => 'error',
            'message'        => "Kon geen SSL verbinding maken: {$errstr}",
        ];
    }

    $params = stream_context_get_params($socket);
    fclose($socket);

    $cert      = $params['options']['ssl']['peer_certificate'] ?? null;
    $cert_info = $cert ? openssl_x509_parse($cert) : null;
    $valid_to  = $cert_info['validTo_time_t'] ?? null;

    if (!$valid_to) {
        return [
            'valid'          => false,
            'days_remaining' => null,
            'expiry_date'    => null,
            'status'         => 'error',
            'message'        => 'Kon vervaldatum niet uitlezen uit certificaat.',
        ];
    }

    $days_remaining = (int) floor(($valid_to - time()) / 86400);
    $expiry_date    = date('Y-m-d', $valid_to);
    $expired        = $days_remaining < 0;

    if ($expired) {
        $status  = 'critical';
        $message = "Certificaat is verlopen op {$expiry_date}.";
    } elseif ($days_remaining <= SH_SSL_CRITICAL_DAYS) {
        $status  = 'critical';
        $message = "Certificaat verloopt over {$days_remaining} dagen ({$expiry_date}) — actie vereist!";
    } else {
        $status  = 'ok';
        $message = "Certificaat geldig tot {$expiry_date} ({$days_remaining} dagen).";
    }

    return [
        'valid'          => !$expired,
        'days_remaining' => $days_remaining,
        'expiry_date'    => $expiry_date,
        'status'         => $status,   // 'ok' | 'critical' | 'error'
        'message'        => $message,
    ];
}

// ─── Callback ─────────────────────────────────────────────────────────────────

function sh_dashboard_update_api_callback($request) {

    // 1. Authenticatie
    $key = $request->get_param('key');
    if ($key !== SH_DASHBOARD_API_KEY) {
        return new WP_REST_Response(['error' => 'Unauthorized', 'message' => 'Ongeldige API Key.'], 401);
    }

    require_once ABSPATH . 'wp-admin/includes/update.php';
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    require_once ABSPATH . 'wp-admin/includes/theme.php';

    try {

        // 2. Update checks (max 1x per 12 uur, forceer via ?force=1)
        $force_check = $request->get_param('force') === '1';
        $last_check  = get_transient('sh_last_update_check');

        if ($force_check || false === $last_check) {
            wp_update_plugins();
            wp_update_themes();
            wp_version_check();
            set_transient('sh_last_update_check', time(), 12 * HOUR_IN_SECONDS);
        }

        $core_updates   = get_site_transient('update_core');
        $plugin_updates = get_site_transient('update_plugins');
        $theme_updates  = get_site_transient('update_themes');

        /* ---------- CORE ---------- */
        $core_current      = get_bloginfo('version');
        $core_latest       = $core_current;
        $core_needs_update = false;

        if (isset($core_updates->updates[0])) {
            $core_latest       = $core_updates->updates[0]->current;
            $core_needs_update = version_compare($core_current, $core_latest, '<');
        }

        /* ---------- PLUGINS ---------- */
        $plugin_list = [];
        foreach (get_plugins() as $path => $data) {
            $needs_update  = isset($plugin_updates->response[$path]);
            $plugin_list[] = [
                'name'         => $data['Name'],
                'current'      => $data['Version'],
                'latest'       => $needs_update ? $plugin_updates->response[$path]->new_version : $data['Version'],
                'needs_update' => $needs_update,
                'active'       => is_plugin_active($path),
            ];
        }

        /* ---------- THEMES ---------- */
        $theme_list = [];
        foreach (wp_get_themes() as $slug => $theme) {
            $needs_update = isset($theme_updates->response[$slug]);
            $theme_list[] = [
                'name'         => $theme->get('Name'),
                'current'      => $theme->get('Version'),
                'latest'       => $needs_update ? $theme_updates->response[$slug]['new_version'] : $theme->get('Version'),
                'needs_update' => $needs_update,
            ];
        }

        /* ---------- HTTP HEALTH CHECK ---------- */
        $http_checks = [];
        $has_errors  = false;
        $error_count = 0;

        $all_posts = get_posts([
            'post_type'      => SH_MONITOR_POST_TYPES,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ]);

        $urls_to_check = [home_url('/')];
        foreach ($all_posts as $post_id) {
            $permalink = get_permalink($post_id);
            if ($permalink && !in_array($permalink, $urls_to_check)) {
                $urls_to_check[] = $permalink;
            }
        }

        // Begrens het aantal te checken URLs om 504 te voorkomen op grote sites
        $total_available = count($urls_to_check);
        $urls_to_check   = array_slice($urls_to_check, 0, SH_HTTP_MAX_URLS);

        // Geef PHP meer tijd voor de health check (wordt genegeerd als host dit niet toestaat)
        @set_time_limit(120);

        foreach ($urls_to_check as $url) {
            $start_time = microtime(true);

            $response = wp_remote_get($url, [
                'timeout'     => SH_HTTP_TIMEOUT,
                'redirection' => 0,
                'sslverify'   => true,
                'user-agent'  => 'Smartheads-Dashboard-Monitor/2.4',
            ]);

            $response_time_ms = round((microtime(true) - $start_time) * 1000);

            if (is_wp_error($response)) {
                $status      = 0;
                $status_text = $response->get_error_message();
                $is_error    = true;
            } else {
                $status      = (int) wp_remote_retrieve_response_code($response);
                $status_text = wp_remote_retrieve_response_message($response);
                $is_error    = ($status >= 400);
            }

            // Offline event loggen als er een fout is
            if ($is_error) {
                $has_errors = true;
                $error_count++;
                sh_append_offline_log($url, $status, $status_text ?: 'Onbekende fout');
            }

            $http_checks[] = [
                'url'              => $url,
                'post_id'          => url_to_postid($url) ?: null,
                'status_code'      => $status,
                'status_text'      => $status_text,
                'response_time_ms' => $response_time_ms,
                'ok'               => ($status >= 200 && $status < 300),
                'is_redirect'      => ($status >= 300 && $status < 400),
                'is_error'         => $is_error,
            ];
        }

        // Sorteer: fouten bovenaan, dan traagste eerst
        usort($http_checks, function($a, $b) {
            if ($a['is_error'] !== $b['is_error']) return $b['is_error'] <=> $a['is_error'];
            return $b['response_time_ms'] <=> $a['response_time_ms'];
        });

        /* ---------- OFFLINE LOG (nieuwste eerst) ---------- */
        $raw_log     = sh_get_offline_log();
        $offline_log = array_map(function($entry) {
            $entry['date'] = date('Y-m-d H:i:s', $entry['timestamp']);
            return $entry;
        }, array_reverse($raw_log));

        /* ---------- SSL CHECK ---------- */
        $site_domain = parse_url(home_url(), PHP_URL_HOST);
        $ssl         = sh_check_ssl($site_domain);

        return new WP_REST_Response([
            'site'    => get_bloginfo('name'),
            'php'     => phpversion(),
            'core'    => [
                'current'      => $core_current,
                'latest'       => $core_latest,
                'needs_update' => $core_needs_update,
            ],
            'plugins' => $plugin_list,
            'themes'  => $theme_list,
            'http_health' => [
                'has_errors'      => $has_errors,
                'error_count'     => $error_count,
                'total_checked'   => count($http_checks),
                'total_available' => $total_available,
                'checks'          => $http_checks,
            ],
            'offline_log' => [
                'total_events' => count($raw_log),
                'events'       => $offline_log,
            ],
            'ssl' => $ssl,
            'last_check_timestamp' => $last_check,
        ], 200);

    } catch (Exception $e) {
        return new WP_REST_Response(['error' => $e->getMessage()], 500);
    }
}